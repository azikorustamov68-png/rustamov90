// Telegram sozlamalari
const CONFIG = {
  BOT_TOKEN: "9039303879:AAG9pZB9t3ngAK9MYm2WL4TamZJ4Pr-ma-Y",
  CHAT_ID: "-1005671860280"
};
