const KEY = 'mega_english_students';
const MONTHS = ['Yan','Fev','Mar','Apr','May','Iyn','Iyl','Avg','Sen','Okt','Noy','Dek'];
const YEAR = new Date().getFullYear();
const NOW = new Date().getMonth();
let students = JSON.parse(localStorage.getItem(KEY) || '[]');

const $ = id => document.getElementById(id);
const money = n => Number(n).toLocaleString('ru-RU') + " so'm";
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const save = () => localStorage.setItem(KEY, JSON.stringify(students));

function toast(msg) {
  const t = $('toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2500);
}

async function tg(text) {
  try {
    const r = await fetch(`https://api.telegram.org/bot${CONFIG.BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({chat_id: CONFIG.CHAT_ID, text, parse_mode: 'HTML'})
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.description);
  } catch (e) { toast('Telegram xatosi: ' + e.message); }
}

function stats() {
  const key = `${YEAR}-${NOW}`;
  const paid = students.filter(s => s.paid[key]);
  $('sTotal').textContent = students.length;
  $('sPaid').textContent = money(paid.reduce((a, s) => a + s.narx, 0));
  $('sDebt').textContent = students.length - paid.length;
}

function render() {
  const q = $('search').value.trim().toLowerCase();
  const list = students.filter(s => (s.ism + ' ' + s.familya + ' ' + s.tel1 + ' ' + s.tel2).toLowerCase().includes(q));
  $('list').innerHTML = list.length ? list.map(s => `
    <div class="stu">
      <div class="head">
        <div>
          <div class="name">${esc(s.ism)} ${esc(s.familya)}</div>
          <div class="meta">📞 ${esc(s.tel1)}${s.tel2 ? ' · ' + esc(s.tel2) : ''}<br>
          📚 ${esc(s.kurs || '—')} · <span class="price">${money(s.narx)}</span></div>
        </div>
        <div><button class="del" onclick="removeStu(${s.id})">🗑 O'chirish</button></div>
      </div>
      <div class="months">${MONTHS.map((m, i) => {
        const on = s.paid[`${YEAR}-${i}`];
        return `<button class="m ${on ? 'on' : ''} ${i === NOW ? 'cur' : ''}" onclick="pay(${s.id},${i})">${on ? '✓ ' : ''}${m}</button>`;
      }).join('')}</div>
    </div>`).join('') : '<div class="empty">O\'quvchilar topilmadi</div>';
  stats();
}

function pay(id, i) {
  const s = students.find(x => x.id === id); const key = `${YEAR}-${i}`;
  s.paid[key] = !s.paid[key]; save(); render();
  tg(s.paid[key]
    ? `💰 <b>To'lov qabul qilindi</b>\n👤 ${esc(s.ism)} ${esc(s.familya)}\n📅 ${MONTHS[i]} ${YEAR}\n💵 ${money(s.narx)}`
    : `↩️ <b>To'lov bekor qilindi</b>\n👤 ${esc(s.ism)} ${esc(s.familya)}\n📅 ${MONTHS[i]} ${YEAR}`);
}

function removeStu(id) {
  if (!confirm("O'quvchini o'chirmoqchimisiz?")) return;
  students = students.filter(s => s.id !== id); save(); render();
}

$('form').addEventListener('submit', e => {
  e.preventDefault();
  const s = {
    id: Date.now(), ism: $('ism').value.trim(), familya: $('familya').value.trim(),
    tel1: $('tel1').value.trim(), tel2: $('tel2').value.trim(),
    kurs: $('kurs').value.trim(), narx: +$('narx').value, paid: {}
  };
  students.unshift(s); save(); render(); e.target.reset(); toast("O'quvchi qo'shildi ✅");
  tg(`🆕 <b>Yangi o'quvchi</b>\n👤 ${esc(s.ism)} ${esc(s.familya)}\n📞 ${esc(s.tel1)}${s.tel2 ? ', ' + esc(s.tel2) : ''}\n📚 ${esc(s.kurs || '—')}\n💵 ${money(s.narx)}/oy`);
});
$('search').addEventListener('input', render);
render();
